helm repo add istio https://istio-release.storage.googleapis.com/charts
*helm pull istio/base

helm install istio-base istio/base -n istio-system --set defaultRevision=default --create-namespace

*helm pull istio/istiod
helm install istiod istio/istiod -n istio-system --wait

kubectl create namespace istio-ingress

*helm pull istio/gateway

 helm install istiod istio/istiod -n istio-system --set pilot.cni.enabled=true --wait

--------------------

images

image: istio/proxyv2:1.27.3
imageID: docker-pullable://istio/proxyv2@sha256:d78126603f2e604b8eff1a2f1bed27cb7ee16a75e5db69bbb909fea2862be873

istio/pilot:1.27.3
imageID: docker-pullable://istio/pilot@sha256:0d1103581b970b5eaaa8aef977779d569a153ebf18b541a88281efdb5a70652c

image: istio/install-cni:1.27.3
imageID: docker-pullable://istio/install-cni@sha256:d154a138edfda0671c613cc8ea1000e6a6142e9e0d47bdc72b3e2489256c2b58
    